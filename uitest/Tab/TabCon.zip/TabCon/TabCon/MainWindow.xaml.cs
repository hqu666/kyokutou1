﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TabCon {
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window {

		public MainWindow()
		{
			InitializeComponent();
		}

		private void TabAdd_Click(object sender, RoutedEventArgs e)
		{
			TabItem tab = new TabItem();
			tab.Header = "Tab" + (MainTab.Items.Count+1);

			var frame = new Frame();
			Child_Page rContent = new Child_Page();
		//	Child_Window rContent = new Child_Window();

			//読込んだページを操作
			rContent.MW = this;
			rContent.CPageCloss_lb.Content = (MainTab.Items.Count + 1) + "番目に追加したページです";
	//		rContent.CwindowCloss_lb.Content = (MainTab.Items.Count + 1) + "番目に追加したページです";
			frame.Navigate(rContent);
			tab.Content = frame;
			tab.IsSelected = true;
			MainTab.Items.Add(tab);
		}

		private void TabDrel_Click(object sender, RoutedEventArgs e)
		{
			DrelTabItem();
		}

		public void DrelTabItem()
		{
			int SelectedIndex = MainTab.SelectedIndex;
			if (-1 < SelectedIndex) {
				MainTab.Items.Remove(MainTab.SelectedItem);
			} else {
				infoLavel.Content = "タブは有りません";
			}
		}

		private void MainTab_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			String NowInfo ="("  + (MainTab.SelectedIndex+1) +"/" + MainTab.Items.Count + ")"+ MainTab.SelectedValue + "を選択";
			infoLavel.Content = NowInfo;
		}

	}


}
